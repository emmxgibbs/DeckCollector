require('./bootstrap');

// import Alpine from 'alpinejs';

// window.Alpine = Alpine;

// Alpine.start();

//initialise Vue components
// import HelloWorld from './components/HelloWorld';

// //register component with Vue
// import { createApp } from 'vue';
// let vueApp = createApp({});
// vueApp.component('hello-world', HelloWorld);
// vueApp.mount('#vue-app');