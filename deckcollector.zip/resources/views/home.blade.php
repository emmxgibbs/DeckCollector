@extends('layouts.main')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in!') }}
                </div>

                <a href="/my-cards" type="button" class="btn btn-sm btn-outline-danger">View my cards!</a>
                <br/>
                <a href="/cards" type="button" class="btn btn-sm btn-outline-danger">View all cards!</a>
            </div>
        </div>
    </div>
</div>
@endsection
