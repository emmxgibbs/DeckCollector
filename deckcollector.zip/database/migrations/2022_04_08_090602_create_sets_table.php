<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
/**
* Run the migrations.
*
* @return void
*/
public function up()
    {
        Schema::create('sets', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->string('tcg_id');
            $table->string('name');
            $table->string('series');
            $table->date('released_at');
            $table->string('logo');
            $table->string('symbol');
    });
}

/**
* Reverse the migrations.
*
* @return void
*/
public function down()
    {
        Schema::dropIfExists('sets');
    }
};