<html>
    sign up
</html><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/PokeTrack/resources/views/signUp.blade.php ENDPATH**/ ?>