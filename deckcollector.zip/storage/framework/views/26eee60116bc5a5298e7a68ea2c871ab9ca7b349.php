<html>
    landing page
</html><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/PokeTrack/resources/views/index.blade.php ENDPATH**/ ?>