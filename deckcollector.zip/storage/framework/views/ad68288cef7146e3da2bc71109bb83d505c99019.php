<!-- can search for users by their username -->

<?php $__env->startSection('content'); ?>

    <h1>
        Users:
    </h1>

    <?php echo e($users->links()); ?>


    <form action="<?php echo e(route('users.index')); ?>" method="GET">
        <label>Search: </label>    
        <input type="text" name="search">

        <button>Search</button>
    </form>
    
    <ul>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                
                <a href="<?php echo e(route('users.show', $user)); ?>">
                    
                    <?php echo e($user->username); ?>


                    <strong>
                        <?php echo e($user->cards->count()); ?>

                    </strong>
                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/DeckCollector/resources/views/users/index.blade.php ENDPATH**/ ?>