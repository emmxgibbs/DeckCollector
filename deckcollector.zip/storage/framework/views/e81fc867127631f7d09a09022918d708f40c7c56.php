<?php $__env->startSection('content'); ?>

    <h2>
        Details for: <?php echo e($card->name); ?>

    </h2>

<div class="row">
    <img class="col-4" src="<?php echo e(URL($card->image_large)); ?>">

    <div class="col-4">
        <div class="row">
        <h4> Average selling price: <?php echo e($card->cardmarket); ?> </h4>
        
        </div>
    </div>

    <div class="col-4">
        <h4> 
            Type: <?php echo e($card->types); ?>

                <br/>
                <br/>
                <br/>
            Evolves From: <a href="/cards?search=<?php echo e($card->evolves_from); ?>"> <?php echo e($card->evolves_from); ?> </a>
        </h4>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/DeckCollector/resources/views/cards/show.blade.php ENDPATH**/ ?>