<?php $__env->startSection('content'); ?>

    <h1>
        Cards
    </h1>

    <?php echo e($cards->links()); ?>


    <form action="<?php echo e(route('users.cards.index')); ?>" method="GET">
        <label>Search: </label>    
        <input type="text" name="search">

        <button>Search</button>
    </form>
    
    <ul>
        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('cards.show', $card)); ?>">
                    <?php echo e($card->card_title); ?>


                    <strong>
                        <?php echo e($card->users->count()); ?>

                    </strong>
                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/DeckCollector/resources/views//my-cards/index.blade.php ENDPATH**/ ?>