<html>
    <body>
        <div class="page" id="sign-up-page">
            <h2>Hello Guest <br> Please enter your email address and create a password to sign up!</h2>

            <form action="submit">
            <div id="email">
                <label for="email">Email address:</label>
                <input type="text">
            </div>

            <div>
                <label for="password">Create password:</label>
                <input type="text">
            </div>

            <div>
                <button>Sign Up</button>
            </div>
            </form>

        </div>
    </body>
</html><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/DeckCollector/resources/views/signUp.blade.php ENDPATH**/ ?>