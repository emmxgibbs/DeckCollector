<?php $__env->startSection('content'); ?>

    <h2>
        Details for: <?php echo e($user -> name); ?>

    </h2>

    <h4>
        Cards (<?php echo e($user->card->count()); ?> cards):
    </h4>

    <ol>
        <?php $__currentLoopData = $user->card->sortBy('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($card->name); ?> (<?php echo e($card->set_name); ?> set_name)
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/DeckCollector/resources/views/card-collection.blade.php ENDPATH**/ ?>