<?php $__env->startSection('content'); ?>
<form style="align-content: center;">
    <div class="mb-3">
        <label for="inputEmail" class="form-label">Email address</label>
        <input type="email" class="form-control" id="inputEmail1" aria-describedby="emailHelp" style="width: auto">
            <div id="emailHelp" class="form-text">
                We'll never share your email with anyone else.
            </div>
    </div>
  
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <input type="password" class="form-control" id="exampleInputPassword1" style="width: auto">
    </div>

    <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Remember me</label>
    </div>

    <button type="submit" class="btn btn-primary">Login</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/DeckCollector/resources/views/deck-collector/login.blade.php ENDPATH**/ ?>