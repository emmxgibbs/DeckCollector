<html>
    login
</html><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/PokeTrack/resources/views/login.blade.php ENDPATH**/ ?>