<html>
    <h2>
        Thank you for signing up! Please keep note of your login credentials!
        <br>
        Happy collecting!
    </h2>
</html><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/DeckCollector/resources/views/submit.blade.php ENDPATH**/ ?>