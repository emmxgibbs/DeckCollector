<html>
    search
</html><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/PokeTrack/resources/views/search.blade.php ENDPATH**/ ?>