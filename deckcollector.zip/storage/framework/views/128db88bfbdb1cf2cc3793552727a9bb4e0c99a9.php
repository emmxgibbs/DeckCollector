<?php $__env->startSection('content'); ?>

<a href="/cards" type="button" class="btn btn-sm btn-outline-danger">View all cards!</a>
<br/>
<br/>

    <h1>
        My Cards:
    </h1>

    <form action="<?php echo e(route('users.cards.index')); ?>" method="GET">
        <label>Search: </label>    
        <input type="text" name="search">

        <button>Search</button>
    </form>
    
    <div class="album py-5 bg-light">
        <div class="container">
            <div class="row">
            
            <?php $__currentLoopData = $userCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-4 shadow-sm">
                        <div class="card-body, center-block" style="padding: 15px; margin: 30px">
                            <div class="d-flex justify-content-between align-items-center" style="flex-direction: column">       
                            <a href="<?php echo e(route('users.cards.show', $card)); ?>" class="text-center" style="color:black">
                                <?php echo e($card->name); ?>

                                <img class="card-img-top" src="<?php echo e(URL($card->image)); ?>" class="img-responsive, img-rounded, hover-shadow">
                            </a>
                                <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked>
                                <label class="form-check-label" for="flexCheckChecked">
                                            Owned
                                </label>
                            </div>
                        </div>
                    </div>     
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


                
                                
                            
           
       
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/DeckCollector/resources/views/my-cards/index.blade.php ENDPATH**/ ?>