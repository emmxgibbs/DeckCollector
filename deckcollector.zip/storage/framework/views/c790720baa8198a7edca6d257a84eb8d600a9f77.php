<?php $__env->startSection('content'); ?>

<!-- displays the cards belonging to a single user -->


    <h2>
        Details for: <?php echo e($user->name); ?>

    </h2>

    <h4>
        Cards (<?php echo e($user->cards->count()); ?> cards):
    </h4>

    <ol>
        <?php $__currentLoopData = $user->cards->sortBy('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($card->card_title); ?> (<?php echo e($card->set_name); ?>)
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/DeckCollector/resources/views/users/show.blade.php ENDPATH**/ ?>