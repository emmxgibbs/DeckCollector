<html>
    <head>
        <meta charset="utf-8">
        <meta content="ie=edge" http-equiv="x-ua-compatible">
        <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport">
        
        <link rel="stylesheet" href="DeckCollector/resources/css/codecamp.css">

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>


<body>

<div class="page-wrapper">
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2 col-sm-10 offset-sm-1">
            <!-- <div class="d-grid gap-2 mx-auto"> -->
                <div class="spacer" style="padding: 15px 0px; height: 1px;"></div>
                <h1 class="text-center">Welcome to freeCodeCamp.org</h1>
                <div class="spacer" style="padding: 15px 0px; height: 1px;"></div>

                <div class="text-center quote-partial">
                    <blockquote class="blockquote">
                        <span>
                            <q> some sort of inspirational quote </q>
                            <div class="spacer" style="padding: 15px 0px; height: 1px;"></div>
                            <footer class="quote-author blockquote-footer">
                            <cite> some author </cite>
                            </footer>
                        </span>
                    </blockquote>
                </div>

                <div class="intro-descrition">
                    <div class="spacer" style="padding: 15px 0px; height: 1px;"></div>
                    <p>
                        If you are new to coding, we recommend you 
                        <a href="https://www.freecodecamp.org/learn/responsive-web-design/basic-html-and-html5/say-hello-to-html-elements">start at the beginning</a>
                        .
                    </p>
                </div>

                <div class="map-ui" data-test-label="learn-curriculum-map">
                    <ul data-test-label="learn-curriculum-map">

                    <li>
                        <a style="background-color: lightgrey; flex: auto;" class="btn link-btn btn-lg" href="/learn/responsive-web-design/">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <span class="sr-only">Laptop and mobile phone icon</span>
                                <svg viewBox="0 0 640 512" xmlns="http://www.w3.org/2000/svg" class="map-icon">
                                <path d="M112 48h352v48h48V32a32.09 32.09 0 00-32-32H96a32.09 32.09 0 00-32 32v256H16a16 16 0 00-16 16v16a64.14 64.14 0 0063.91 64H352v-96H112zm492 80H420a36 36 0 00-36 36v312a36 36 0 0036 36h184a36 36 0 0036-36V164a36 36 0 00-36-36zm-12 336H432V176h160z">
                                </path>
                                </svg>
                                Responsive Web Design Certification (300 hours)
                            </div>
                        </a>
                    </li>
                    
                    <button style="background-color:lightgrey" class="btn btn-primary" type="button">JavaScript Algorithms and Data Structures Certification (300 hours)</button>
                    <button style="background-color:lightgrey" class="btn btn-primary" type="button">Front End Development Libraries Certification (300 hours))</button>
                    <button style="background-color:lightgrey" class="btn btn-primary" type="button">Data Visualization Certification (300 hours)</button>
                    <button style="background-color:lightgrey" class="btn btn-primary" type="button">Back End Development and APIs Certification (300 hours)</button>
                    <button style="background-color:lightgrey" class="btn btn-primary" type="button">Quality Assurance Certification (300 hours)</button>
  <div style="display: flex; justify-content: space-between; align-items: center;">
                    <button style="background-color:lightgrey" class="btn btn-primary" type="button"> <svg viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg" class="map-icon"></svg>
      <path d="M439.8 200.5c-7.7-30.9-22.3-54.2-53.4-54.2h-40.1v47.4c0 36.8-31.2 67.8-66.8 67.8H172.7c-29.2 0-53.4 25-53.4 54.3v101.8c0 29 25.2 46 53.4 54.3 33.8 9.9 66.3 11.7 106.8 0 26.9-7.8 53.4-23.5 53.4-54.3v-40.7H226.2v-13.6h160.2c31.1 0 42.6-21.7 53.4-54.2 11.2-33.5 10.7-65.7 0-108.6zM286.2 404c11.1 0 20.1 9.1 20.1 20.3 0 11.3-9 20.4-20.1 20.4-11 0-20.1-9.2-20.1-20.4.1-11.3 9.1-20.3 20.1-20.3zM167.8 248.1h106.8c29.7 0 53.4-24.5 53.4-54.3V91.9c0-29-24.4-50.7-53.4-55.6-35.8-5.9-74.7-5.6-106.8.1-45.2 8-53.4 24.7-53.4 55.6v40.7h106.9v13.6h-147c-31.1 0-58.3 18.7-66.8 54.2-9.8 40.7-10.2 66.1 0 108.6 7.6 31.6 25.7 54.2 56.8 54.2H101v-48.8c0-35.3 30.5-66.4 66.8-66.4zm-6.7-142.6c-11.1 0-20.1-9.1-20.1-20.3.1-11.3 9-20.4 20.1-20.4 11 0 20.1 9.2 20.1 20.4s-9 20.3-20.1 20.3z">    
      </path> Scientific Computing with Python Certification (300 hours)</button>
  </div>
                    <button style="background-color:lightgrey" class="btn btn-primary" type="button">Data Analysis with Python Certification (300 hours)</button>
                    <button style="background-color:lightgrey" class="btn btn-primary" type="button">Information Security Certification (300 hours)</button>
                    <button style="background-color:lightgrey" class="btn btn-primary" type="button">Machine Learning with Python Certification (300 hours)</button>
                    <button style="background-color:lightgrey" class="btn btn-primary" type="button">Coding Interview Prep (Thousands of hours of challenges)</button>
                    <button style="background-color:lightgrey" class="btn btn-primary" type="button">Responsive Web Design (Beta) Certification (300 hours)</button>
                    <button style="background-color:lightgrey" class="btn btn-primary" type="button">Relational Database (Beta) Certification (300 hours)</button>


                    </ul>
                    </div>
</div>
</div>






<footer class="site-footer">
    <div class="footer-container">
        <div class="footer-top">
            <div class="footer-desc-col">
                <p>freeCodeCamp is a donor-supported tax-exempt 501(c)(3) nonprofit organization (United States Federal Tax Identification Number: 82-0779546)</p>
                <p>Our mission: to help people learn to code for free. We accomplish this by creating thousands of videos, articles, and interactive coding lessons - all freely available to the public. We also have thousands of freeCodeCamp study groups around the world.</p>
                <p>Donations to freeCodeCamp go toward our education initiatives, and help pay for servers, services, and staff.</p>
                <p class="footer-donation">You can <a class="inline" href="/donate">make a tax-deductible donation here</a>.</p>
            </div>
            <div class="trending-guides">
                <div class="col-header">Trending Guides</div>
                <div class="trending-guides-row">
                    <div class="footer-col footer-col-1">
                        <a href="https://www.freecodecamp.org/news/csv-format-how-to-open-a-csv-file-and-export-it/" rel="noopener noreferrer" target="_blank">CSV File Format</a>
                        <a href="https://www.freecodecamp.org/news/python-open-file-how-to-read-a-text-file-line-by-line/" rel="noopener noreferrer" target="_blank">Python Open File</a>
                        <a href="https://www.freecodecamp.org/news/python-sort-list-how-to-order-by-descending-or-ascending/" rel="noopener noreferrer" target="_blank">Python Sort List</a>
                        <a href="https://www.freecodecamp.org/news/javascript-online-html-css-js-code-editor-list-browser-ide-tools/" rel="noopener noreferrer" target="_blank">JavaScript Online</a>
                        <a href="https://www.freecodecamp.org/news/python-create-file-how-to-append-and-write-to-a-text-file/" rel="noopener noreferrer" target="_blank">Python Create File</a>
                        <a href="https://www.freecodecamp.org/news/how-to-mute-and-unmute-on-zoom-keyboard-shortcut/" rel="noopener noreferrer" target="_blank">How to mute on Zoom</a>
                        <a href="https://www.freecodecamp.org/news/python-do-while-loop-example/" rel="noopener noreferrer" target="_blank">Python Do While Loop</a>
                        <a href="https://www.freecodecamp.org/news/python-print-variable-how-to-print-a-string-and-variable/" rel="noopener noreferrer" target="_blank">Python Print Variable</a>
                        <a href="https://www.freecodecamp.org/news/span-vs-div-html-tags-what-is-the-difference/" rel="noopener noreferrer" target="_blank">Span vs Div HTML Tags</a>
                        <a href="https://www.freecodecamp.org/news/what-is-a-function-javascript-function-examples/" rel="noopener noreferrer" target="_blank">Function in JS Example</a>
                    </div>
                    <div class="footer-col footer-col-2">
                        <a href="https://www.freecodecamp.org/news/html-div-what-is-a-div-tag-and-how-to-style-it-with-css/" rel="noopener noreferrer" target="_blank">HTML Div</a>
                        <a href="https://www.freecodecamp.org/news/learn-sql-free-relational-database-courses-for-beginners/" rel="noopener noreferrer" target="_blank">Learn SQL</a>
                        <a href="https://www.freecodecamp.org/news/all-emojis-emoji-list-for-copy-and-paste/" rel="noopener noreferrer" target="_blank">Emoji List</a>
                        <a href="https://www.freecodecamp.org/news/html-tables-table-tutorial-with-css-example-code/" rel="noopener noreferrer" target="_blank">HTML Tables</a>
                        <a href="https://www.freecodecamp.org/news/ascending-order-with-sql-order-by/" rel="noopener noreferrer" target="_blank">SQL Order By</a>
                        <a href="https://www.freecodecamp.org/news/html-padding-css-padding-order/" rel="noopener noreferrer" target="_blank">HTML Padding</a>
                        <a href="https://www.freecodecamp.org/news/learn-python-free-python-courses-for-beginners/" rel="noopener noreferrer" target="_blank">Learn Python</a>
                        <a href="https://www.freecodecamp.org/news/css-font-color-how-to-style-text-in-html/" rel="noopener noreferrer" target="_blank">CSS Font Color</a>
                        <a href="https://www.freecodecamp.org/news/free-textbooks-math-science-and-more-online-pdf-for-college-and-high-school/" rel="noopener noreferrer" target="_blank">Free Textbooks</a>
                        <a href="https://www.freecodecamp.org/news/css-positioning-position-absolute-and-relative/" rel="noopener noreferrer" target="_blank">CSS Positioning</a>
                    </div>
                    <div class="footer-col footer-col-3">
                        <div class="footer-left">
                            <a href="https://www.freecodecamp.org/news/transparent-background-image-opacity-in-css-and-html/" rel="noopener noreferrer" target="_blank">Transparent Background</a>
                            <a href="https://www.freecodecamp.org/news/how-to-save-a-google-doc-as-a-pdf/" rel="noopener noreferrer" target="_blank">Save Google Doc as PDF</a>
                            <a href="https://www.freecodecamp.org/news/java-array-declaration-how-to-initialize-an-array-in-java-with-example-code/" rel="noopener noreferrer" target="_blank">Java Array Declaration</a>
                            <a href="https://www.freecodecamp.org/news/javascript-switch-case-js-switch-statement-example/" rel="noopener noreferrer" target="_blank">JavaScript Switch Case</a>
                            <a href="https://www.freecodecamp.org/news/rest-api-best-practices-rest-endpoint-design-examples/" rel="noopener noreferrer" target="_blank">REST API best practices</a>
                        </div>
                        <div class="footer-right">
                            <a href="https://www.freecodecamp.org/news/what-is-graphic-design-the-graphic-designer-job-explained-in-plain-english/" rel="noopener noreferrer" target="_blank">What is Graphic Design?</a>
                            <a href="https://www.freecodecamp.org/news/share-screen-on-android-how-to-cast-my-screen-with-a-windows-10-pc/" rel="noopener noreferrer" target="_blank">Share Screen on Android</a>
                            <a href="https://www.freecodecamp.org/news/there-was-a-problem-with-resetting-your-pc-reset-pc-fixed-on-windows-10/" rel="noopener noreferrer" target="_blank">Problem Resetting Your PC</a>
                            <a href="https://www.freecodecamp.org/news/how-to-open-task-manager-in-windows-10/" rel="noopener noreferrer" target="_blank">Open Task Manager Windows 10</a>
                            <a href="https://www.freecodecamp.org/news/how-to-delete-albums-on-iphone/" rel="noopener noreferrer" target="_blank">Delete Albums on iPhone</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="col-header">Our Nonprofit</div>
                <div class="footer-divder">
                </div>
                <div class="our-nonprofit">
                    <a href="https://www.freecodecamp.org/news/about/" rel="noopener noreferrer" target="_blank">About</a>
                    <a href="https://www.linkedin.com/school/free-code-camp/people/" rel="noopener noreferrer" target="_blank">Alumni Network</a>
                    <a href="https://github.com/freeCodeCamp/" rel="noopener noreferrer" target="_blank">Open Source</a>
                    <a href="https://www.freecodecamp.org/shop/" rel="noopener noreferrer" target="_blank">Shop</a>
                    <a href="https://www.freecodecamp.org/news/support/" rel="noopener noreferrer" target="_blank">Support</a>
                    <a href="https://www.freecodecamp.org/news/sponsors/" rel="noopener noreferrer" target="_blank">Sponsors</a>
                    <a href="https://www.freecodecamp.org/news/academic-honesty-policy/" rel="noopener noreferrer" target="_blank">Academic Honesty</a>
                    <a href="https://www.freecodecamp.org/news/code-of-conduct/" rel="noopener noreferrer" target="_blank">Code of Conduct</a>
                    <a href="https://www.freecodecamp.org/news/privacy-policy/" rel="noopener noreferrer" target="_blank">Privacy Policy</a>
                    <a href="https://www.freecodecamp.org/news/terms-of-service/" rel="noopener noreferrer" target="_blank">Terms of Service</a>
                    <a href="https://www.freecodecamp.org/news/copyright-policy/" rel="noopener noreferrer" target="_blank">Copyright Policy</a>
                </div>
            </div>
        </div>
    </footer>
</div>
</body>
</html><?php /**PATH /home/emma/Documents/Alacrity/alacrityBootcamp/DeckCollector/resources/views/codecamp.blade.php ENDPATH**/ ?>